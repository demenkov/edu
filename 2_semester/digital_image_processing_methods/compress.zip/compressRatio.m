function k = compressRatio(img1, img2)
%COMPRESSRATIO Степень (коэффициент) сжатия изображения.
%   k = compressRatio(IMG1, IMG2) возвращает безразмерный коэффициент
%   сжатия Ксж = Im1 / Im2, где Im1 и Im2 — объёмы файлов изображений
%   в байтах. Аргументы IMG1 и IMG2 — строки с путями к файлам.
%   Объём файла определяется по полю FileSize структуры imfinfo.
%
%   Пример:
%       k = compressRatio('results/original.bmp', 'results/iter_05.jpg');

Im1 = fileBytes(img1);   % объём исходного изображения, байт
Im2 = fileBytes(img2);   % объём сжатого изображения,  байт
k   = Im1 / Im2;
end

function b = fileBytes(x)
if ischar(x) || isstring(x)
    info = imfinfo(char(x));
    b = info.FileSize;
else
    error('compressRatio:badInput', ...
        'Ожидается путь к файлу изображения (строка).');
end
end