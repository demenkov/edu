function image = invertDCT(coeffs)
%INVERTDCT Обратное двумерное ДКП изображения блоками 8x8 по формуле (5).
%   IMAGE = invertDCT(COEFFS) для каждого блока 8x8 матрицы частотных
%   коэффициентов COEFFS восстанавливает значения яркости по формуле:
%
%       f(x,y) = SUM_i SUM_j C(i)C(j) * ДКП(i,j) *
%                cos[(2x+1)i*pi/2N] * cos[(2y+1)j*pi/2N],
%
%   где C(i)=sqrt(1/N) при i=1 и C(i)=sqrt(2/N) при i=2..N, N=8.

N = 8;
image = blockproc(coeffs, [N N], @(bs) idctBlock(bs.data, N));
end

function A = idctBlock(C, N)
%IDCTBLOCK Обратное ДКП одного блока C размером NxN по формуле (5).
A = zeros(N, N);
for x = 0:N-1
    for y = 0:N-1
        s = 0;
        for u = 0:N-1
            for v = 0:N-1
                s = s + alpha(u, N) * alpha(v, N) * C(u+1, v+1) * ...
                    cos((2*x+1)*u*pi/(2*N)) * ...
                    cos((2*y+1)*v*pi/(2*N));
            end
        end
        A(x+1, y+1) = s;
    end
end
end

function a = alpha(k, N)
if k == 0
    a = sqrt(1/N);
else
    a = sqrt(2/N);
end
end