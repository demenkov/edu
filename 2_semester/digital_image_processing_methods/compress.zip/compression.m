%% Практическая работа «Сжатие изображений в системе MATLAB»
%  Исследование JPEG-сжатия: блочное ДКП, постепенное обнуление
%  высокочастотных коэффициентов, оценка степени сжатия и качества.
%
%  Используемые функции (отдельные файлы):
%     compressRatio.m  — коэффициент сжатия Ксж = Im1/Im2;
%     directDCT.m      — прямое блочное ДКП 8x8 по формуле (1);
%     invertDCT.m      — обратное блочное ДКП 8x8 по формуле (5);
%     zigzagOrder.m    — порядок зигзаг-сканирования коэффициентов.

clc; clear; close all;

%% 1. Исходные данные
imagePath = 'cameraman.tif';     % входит в поставку MATLAB (256x256, grayscale)

f = imread(imagePath);
if size(f, 3) == 3               % при необходимости перевод в полутоновое
    f = rgb2gray(f);
end
f = im2double(f);                % приведение к диапазону [0, 1]

if ~exist('results', 'dir'); mkdir('results'); end
imwrite(im2uint8(f), 'results/original.bmp');   % несжатый эталон (Im1)

%% 2. Прямое ДКП всего изображения (один раз)
coeffs = directDCT(f);
order  = zigzagOrder(8);          % низкочастотные -> высокочастотные

%% 3. 12 итераций постепенного обнуления коэффициентов
nIter = 12;
% число сохраняемых коэффициентов в каждом блоке: от 64 (без сжатия) до 1 (только DC)
keepCounts = round(linspace(64, 1, nIter));

usedCoeffs = zeros(1, nIter);     % задействовано коэффициентов
ratio      = zeros(1, nIter);     % уровень сжатия
quality    = zeros(1, nIter);     % корреляция Пирсона (качество)
recon      = cell(1, nIter);      % восстановленные изображения

fprintf('%4s %12s %14s %16s\n', 'Итер', 'Коэфф.', 'Сжатие Ксж', 'Корреляция');
for it = 1:nIter
    nKeep = keepCounts(it);

    % маска: сохраняем первые nKeep коэффициентов зигзага, остальные — 0
    mask = zeros(8, 8);
    mask(order(1:nKeep)) = 1;     % DC (order(1)) сохраняется всегда

    % применяем маску к каждому блоку коэффициентов
    maskedCoeffs = blockproc(coeffs, [8 8], @(bs) bs.data .* mask);

    % восстановление изображения обратным ДКП
    f2 = invertDCT(maskedCoeffs);
    f2 = min(max(f2, 0), 1);      % ограничение диапазона [0, 1]
    recon{it} = f2;

    % качество: коэффициент корреляции Пирсона между исходным и сжатым
    quality(it)    = corr2(f, f2);
    usedCoeffs(it) = nKeep;

    % уровень сжатия: сохраняем результат как JPEG и сравниваем объёмы файлов
    fn = sprintf('results/iter_%02d.jpg', it);
    imwrite(im2uint8(f2), fn);
    ratio(it) = compressRatio('results/original.bmp', fn);

    fprintf('%4d %12d %14.3f %16.4f\n', it, nKeep, ratio(it), quality(it));
end

%% 4. Графики (задание 6)
% а) качество в зависимости от количества задействованных коэффициентов
[xc, sc] = sort(usedCoeffs);
figure('Name', 'Качество vs коэффициенты');
plot(xc, quality(sc), '-o', 'LineWidth', 1.5);
grid on;
xlabel('Количество задействованных коэффициентов');
ylabel('Качество (коэффициент корреляции Пирсона)');
title('Зависимость качества от числа коэффициентов ДКП');

% б) качество в зависимости от уровня сжатия
[xr, sr] = sort(ratio);
figure('Name', 'Качество vs сжатие');
plot(xr, quality(sr), '-s', 'LineWidth', 1.5);
grid on;
xlabel('Уровень сжатия (К_{сж})');
ylabel('Качество (коэффициент корреляции Пирсона)');
title('Зависимость качества от уровня сжатия');

%% 5. Сравнение изображений в одном окне (задания 8, 9)
show = [1 4 8 11 12];             % какие итерации показать
figure('Name', 'Исходное и сжатые изображения');
subplot(2, 3, 1); imshow(f); title('Исходное');
for k = 1:numel(show)
    it = show(k);
    subplot(2, 3, k + 1); imshow(recon{it});
    title(sprintf('Коэфф.=%d, К_{сж}=%.1f', usedCoeffs(it), ratio(it)));
end

%% 6. Итоговая таблица результатов
T = table((1:nIter)', usedCoeffs', ratio', quality', ...
    'VariableNames', {'Iteration', 'UsedCoeffs', 'CompressRatio', 'Correlation'});
disp(T);
writetable(T, 'results/results.csv');
fprintf('\nГотово. Результаты сохранены в папке results/.\n');