function coeffs = directDCT(image)
%DIRECTDCT Прямое двумерное ДКП изображения блоками 8x8 по формуле (1).
%   COEFFS = directDCT(IMAGE) разбивает изображение IMAGE (матрица
%   яркостей класса double) на блоки 8x8 и для каждого блока вычисляет
%   матрицу частотных коэффициентов прямого дискретного косинусного
%   преобразования по формуле:
%
%       ДКП(i,j) = C(i)C(j) * SUM_x SUM_y f(x,y) *
%                  cos[(2x+1)i*pi/2N] * cos[(2y+1)j*pi/2N],
%
%   где C(i)=sqrt(1/N) при i=1 и C(i)=sqrt(2/N) при i=2..N, N=8.
%   Результат COEFFS — изображение того же размера, содержащее
%   частотные коэффициенты по блокам.

N = 8;
coeffs = blockproc(image, [N N], @(bs) dctBlock(bs.data, N));
end

function C = dctBlock(A, N)
%DCTBLOCK Прямое ДКП одного блока A размером NxN по формуле (1).
C = zeros(N, N);
for u = 0:N-1
    for v = 0:N-1
        au = alpha(u, N);
        av = alpha(v, N);
        s = 0;
        for x = 0:N-1
            for y = 0:N-1
                s = s + A(x+1, y+1) * ...
                    cos((2*x+1)*u*pi/(2*N)) * ...
                    cos((2*y+1)*v*pi/(2*N));
            end
        end
        C(u+1, v+1) = au * av * s;
    end
end
end

function a = alpha(k, N)
if k == 0
    a = sqrt(1/N);
else
    a = sqrt(2/N);
end
end