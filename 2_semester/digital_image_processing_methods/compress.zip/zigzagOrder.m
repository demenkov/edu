function order = zigzagOrder(N)
%ZIGZAGORDER Линейные индексы элементов матрицы NxN в порядке зигзаг-сканирования.
%   ORDER = zigzagOrder(N) возвращает вектор-строку длины N*N линейных
%   (столбцовых) индексов MATLAB, перечисляющих элементы матрицы NxN от
%   низкочастотного (DC, верхний левый угол) к высокочастотным.
%   Обнуление коэффициентов в порядке, обратном зигзагу, выполняется
%   отбрасыванием последних элементов ORDER.

order = zeros(1, N*N);
idx = 1;
for s = 0:(2*N - 2)            % номер диагонали (row+col), 0-based
    if mod(s, 2) == 0          % чётные диагонали — снизу вверх
        r = min(s, N-1);
        c = s - r;
        while r >= 0 && c < N
            order(idx) = c*N + r + 1;   % столбцовый индекс MATLAB
            idx = idx + 1; r = r - 1; c = c + 1;
        end
    else                       % нечётные диагонали — сверху вниз
        c = min(s, N-1);
        r = s - c;
        while c >= 0 && r < N
            order(idx) = c*N + r + 1;
            idx = idx + 1; c = c - 1; r = r + 1;
        end
    end
end
end